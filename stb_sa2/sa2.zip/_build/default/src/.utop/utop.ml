Clflags.include_dirs :=
  [ "/home/alex/.opam/system/lib/bytes"
  ; "/home/alex/.opam/system/lib/camomile"
  ; "/home/alex/.opam/system/lib/camomile/default_config"
  ; "/home/alex/.opam/system/lib/camomile/dyn"
  ; "/home/alex/.opam/system/lib/camomile/lib_default"
  ; "/home/alex/.opam/system/lib/camomile/library"
  ; "/home/alex/.opam/system/lib/findlib"
  ; "/home/alex/.opam/system/lib/lambda-term"
  ; "/home/alex/.opam/system/lib/lwt"
  ; "/home/alex/.opam/system/lib/lwt/unix"
  ; "/home/alex/.opam/system/lib/lwt_log"
  ; "/home/alex/.opam/system/lib/lwt_log/core"
  ; "/home/alex/.opam/system/lib/lwt_react"
  ; "/home/alex/.opam/system/lib/react"
  ; "/home/alex/.opam/system/lib/result"
  ; "/home/alex/.opam/system/lib/utop"
  ; "/home/alex/.opam/system/lib/zed"
  ; "/usr/lib/ocaml/compiler-libs"
  ; "/usr/lib/ocaml/threads"
  ; "/home/alex/stevens/CS496/stb_sa2/_build/default/src/.sool.objs"
  ];

UTop_main.main ();
